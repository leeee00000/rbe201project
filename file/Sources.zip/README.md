# RBE201TC Robot Code Package

Python and C programs for testing and operating an RDK X5 robot with a four-channel motor driver, four line-tracking sensors and a DHT11 temperature and relative humidity sensor.

The integrated application follows a black-tape route, detects transverse black markers, requests temperature and humidity readings, and maintains a separate CSV file for each run. Each event is saved before its reading is requested and then updated with its final outcome. Measurements are asynchronous: the robot continues moving while the sensor is read.

Use `RBE201TC_RDK_Robot_Manual_AY2627.docx` as the main laboratory guide. Its software setup, component tests, integrated run commands and data-recording instructions are complete; this README provides the matching code reference.

## Package contents

```text
RBE201TC/
├── moto_test.py
├── line_sensor_test.py
├── dht11_rdk_x5_test.c
├── dht11_rdk_x5_gpio401.c
└── line_follower.py
```

| File | Purpose |
| --- | --- |
| `moto_test.py` | Tests all motors, individual motors, motor pairs or manual speed commands. |
| `line_sensor_test.py` | Prints the digital states of the four tracking inputs. |
| `dht11_rdk_x5_test.c` | Standalone DHT11 test with success/failure reporting. |
| `dht11_rdk_x5_gpio401.c` | DHT11 test and standard-input/output service used by the integrated application. |
| `line_follower.py` | Controls line following, detects markers, manages the DHT11 subprocess and logs readings. |

The code directory contains source files. Compiled executables, Python dependencies, recorded data, room coordinates and MATLAB mapping scripts are not included. The package also contains this README and the Word laboratory manual.

## Requirements

Run these programs on the RDK X5 using the provided Linux image and the matching hardware configuration.

- Python 3 with `serial` (pySerial) and `Hobot.GPIO`.
- GCC to compile the C programs.
- `chrt` and `taskset` from `util-linux`.
- A compatible `/sys/class/gpio` interface for the DHT11 programs.
- A USB-connected motor driver, four tracking inputs and a DHT11 sensor.
- Root privileges for the DHT11 programs and integrated application.

Keep the wheels clear of the ground during initial motor tests. Verify regulated power, wiring and polarity before switching on. Keep the motor power switch accessible and confirm that stopping works before floor operation.

## Default hardware configuration

Verify these software defaults against the actual board, wiring and image before running the programs. Physical header pin numbers and Linux GPIO numbers are different numbering systems.

| Setting | Default |
| --- | --- |
| Motor serial port | `/dev/ttyUSB0` |
| Serial baud rate | `115200` |
| Left motors in the integrated application | M1 and M2 |
| Right motors in the integrated application | M3 and M4 |
| Tracking numbering mode | `GPIO.BOARD` (physical header pins) |
| X1 / X2 / X3 / X4 | Physical pins 15 / 18 / 16 / 11 |
| Tracking order assumed by the controller | X1 to X4, left to right |
| Black-tape input level | `0` |
| DHT11 data | Linux GPIO 401; identified by the C programs as physical pin 37 |
| DHT11 supply | Identified by the C programs as physical pin 1 (3.3 V) and pin 6 (GND) |

Confirm each motor's direction and each sensor's black/white response experimentally.

To change the serial device, check the driver instance in `moto_test.py` and `SERIAL_PORT` in `line_follower.py`. Keep tracking pin changes consistent between the two tracking scripts. Both C files contain GPIO-specific definitions, paths and cleanup values; changing the filename alone does not change the GPIO configuration.

## Setup

Extract the package so that all five source files are directly inside `~/RBE201TC`. Avoid an unintended nested `~/RBE201TC/RBE201TC` directory. Run the following commands on the RDK:

```bash
cd ~/RBE201TC
ls

sudo apt update
sudo apt install -y gcc g++ make util-linux git \
  python3 python3-pip python3-dev python3-serial

python3 -c "import serial; print(serial.__version__)"
python3 -c "import Hobot.GPIO; print('Hobot.GPIO OK')"
sudo python3 -c "import serial; import Hobot.GPIO; print('Dependencies OK')"
command -v gcc chrt taskset
```

`python3-serial` provides the Python module named `serial`. `Hobot.GPIO` must be available in the board's configured Python environment; it is not supplied in this package. The final command should print paths for `gcc`, `chrt` and `taskset`. If a tool is missing or either the ordinary or sudo import check fails, check the supplied image and Python environment before continuing. Use the provided image without a full system upgrade during the laboratory session.

For motor tests without root privileges, add your account to the serial-access group:

```bash
sudo usermod -aG dialout "$USER"
```

Log out and back in, then check:

```bash
groups
ls -l /dev/ttyUSB* /dev/ttyACM*
```

An unmatched device pattern may report that no such file exists. Identify the actual motor-driver port and update the scripts if necessary. Do not run two motor-control programs on the same port simultaneously.

## Build the DHT11 programs

```bash
cd ~/RBE201TC
gcc dht11_rdk_x5_test.c -o dht11_test -Wall
gcc dht11_rdk_x5_gpio401.c -o dht11_rdk_x5_gpio401_server -Wall
chmod +x dht11_rdk_x5_gpio401_server
```

The integrated application requires the exact executable name `dht11_rdk_x5_gpio401_server` in the same directory as `line_follower.py`.

## Test the components

Stop each test before starting the next one.

### 1. Motors

Secure the robot with all wheels raised, then run:

```bash
python3 moto_test.py
```

The menu offers:

| Option | Test |
| --- | --- |
| `1` | Basic functionality test of all motors |
| `2` | Individual motor test |
| `3` | Motor pair test |
| `4` | Manual control |

Pressing Enter selects option `1`. Start with option `2` to identify the wheel connected to each channel and verify its direction.

In manual mode, enter four space-separated speed values. Use `s` to stop all motors and `q` to exit. Press `Ctrl+C` to interrupt a test. Confirm that the wheels actually stop; disconnect motor power if they do not.

### 2. Tracking sensors

```bash
sudo python3 line_sensor_test.py
```

Move each sensor over black tape and the surrounding light surface at the intended mounting height and lighting conditions. Record the input levels and physical left-to-right order. The integrated controller assumes black reads `0`.

Press `Ctrl+C` to exit and release the GPIO resources.

### 3. DHT11

```bash
sudo ./dht11_test
```

The program prints temperature, relative humidity and success/failure counts. It waits approximately two seconds between read attempts. Confirm valid readings, then press `Ctrl+C` to stop.

Alternatively, the second executable also supports standalone testing:

```bash
sudo ./dht11_rdk_x5_gpio401_server
```

Do not run either standalone DHT11 test while the integrated application is running: they use the same GPIO.

## Run the integrated application

After component checks, prepare a short black-tape route with transverse black markers and a clear operating area. Verify the system clock and timezone before collecting timestamped measurements.

```bash
cd ~/RBE201TC
date -Is
sudo python3 -c "import serial; import Hobot.GPIO; print('Dependencies OK')"
sudo python3 line_follower.py
```

The current application explicitly requires root privileges. Dependencies must therefore also be importable under `sudo python3`.

The application automatically starts its DHT11 subprocess with the equivalent of:

```bash
chrt -f 50 taskset -c 7 ./dht11_rdk_x5_gpio401_server --server
```

Do not start this service separately for normal operation. It communicates through standard input/output, not a network port. Its commands are `READ <point_id>` and `QUIT`.

### Control and marker settings

The main configuration constants are near the top of `line_follower.py`.

| Constant | Default | Meaning |
| --- | ---: | --- |
| `BASE_PWM` | 220 | Base driving PWM command |
| `MAX_PWM` | 300 | Maximum configured PWM command |
| `CONTROL_HZ` | 50.0 | Target control-loop frequency |
| `BLACK_LEVEL` | 0 | Digital input interpreted as black |
| `MARKER_CONFIRM_SECONDS` | 0.04 | Continuous all-black duration required to trigger a marker |
| `MARKER_CLEAR_SECONDS` | 0.10 | Continuous departure from all-black required to re-arm detection |
| `DHT_CPU_CORE` | 7 | CPU used for the DHT11 subprocess |
| `DHT_RT_PRIORITY` | 50 | FIFO real-time scheduling priority |
| `DHT_REQUEST_TIMEOUT_SECONDS` | 10.0 | Maximum time for a request to receive a result, measured with a monotonic clock |

These are source-code defaults, not validated settings for every robot. Check motor direction and use conservative settings during initial trials. If CPU 7 is unavailable or scheduling fails, check the board image, available CPUs and permissions before changing the configuration.

When all four sensors remain on black for the confirmation interval, the application assigns the next detection number, saves a `pending` event and requests a reading. It latches the marker until the clear interval has elapsed.

**The robot does not stop to let the DHT11 settle.** A reading can correspond to a position after the trigger location. Evaluate this delay and sensor response when interpreting measurements. A transverse marker is not an end-of-route stop command.

Press `Ctrl+C` to stop. Unfinished readings are marked `cancelled` during normal shutdown. The program includes motor-stop and resource-cleanup logic, but the physical stop must be verified. Keep an operator ready to disconnect motor power.

If a motor motion or braking command cannot be sent, the controller enters a fault state, stops normal control and attempts to send emergency-stop commands before exiting. A CSV save failure also ends the run and triggers a stop attempt. A message confirming that a command was sent does not confirm physical wheel motion or stopping; disconnect motor power if the wheels keep moving. Sensor failures, request failures and request timeouts are recorded as measurement outcomes and do not themselves stop line following.

## CSV output

Each run creates `temperature_points_<RunID>.csv` beside `line_follower.py`, regardless of the terminal's current directory. The program prints the actual path at startup. `RunID` contains a UTC timestamp and a random suffix; it also appears in every data row. The CSV uses `utf-8-sig` encoding.

There is one row per detected event. The application saves that row with status `pending` before sending `READ` to the sensor service. It then updates the same row with a final status. Updates replace the file atomically, so readers see a complete saved version. Reload the file to see later updates; copy it after the program has stopped for analysis.

| Column | Meaning |
| --- | --- |
| `RunID` | Unique identifier for the current program run |
| `Detection point` | Sequential marker-event number for the current program run |
| `Trigger time` | Local timestamp when the marker event was recorded, including timezone offset |
| `Result time` | Local timestamp when the final outcome was determined, including timezone offset; empty while pending |
| `Humidity_%RH` | Relative humidity in %RH |
| `Temperature_°C` | Temperature in degrees Celsius |
| `Status` | Event state from the table below |
| `Explanation` | Error details or supplementary information |

| Status | Meaning |
| --- | --- |
| `pending` | Event saved; no final outcome has been saved yet |
| `success` | Valid sensor response received and the result saved |
| `sensor_failure` | Sensor reported an error, its response was invalid, or the service ended before returning a pending result |
| `request_failure` | The service was unavailable or the request could not be sent |
| `timeout` | No result arrived within the configured request timeout |
| `cancelled` | The run stopped while the event was still pending |

Only `success` rows contain measurements for analysis. Failed or unfinished measurements have empty value fields; do not replace them with zero. A final outcome is not overwritten by a late or duplicate sensor reply. The C service still uses `OK` / `ERROR` in its internal protocol; the Python program maps these to the CSV states above. `Saved` is printed only after a successful CSV write.

On a save failure the program reports the error and stops; the last successfully saved file is retained. Sudden power loss, forced termination or a persistent storage fault may leave `pending` rows. Treat those as incomplete events, not successful readings, and keep the file for investigation.

### Keep runs distinguishable

Detection numbering restarts when the application restarts. Each run automatically receives a new RunID and a separate file, so manual renaming before the next run is unnecessary. Use the pair `RunID` and `Detection point` to identify an event. After stopping, copy that run's CSV to the group archive and confirm that it opens correctly.

Legacy `temperature_points.csv` files are left untouched. Their `succeed` / `Fail` status values belong to the previous format; record any conversion explicitly when combining old and new datasets.

Keep the source version, parameter settings, clock information and failed-run records with the data. Do not adjust the system clock during collection.

### Associate readings with locations

Detection numbers are event identifiers, not coordinates. The package does not assign room positions or generate maps.

For spatial analysis, maintain a separate table linking each run and detection event to a station ID, measured X/Y coordinates and sensor height. Check for missed or repeated triggers before joining this table to the CSV. Preserve the original log and record any cleaning or status conversion in a separate analysis dataset.

Use the location-linked data in MATLAB or another analysis tool to generate temperature and relative humidity maps. Distinguish measured values from interpolated estimates and document coverage, missing readings and motion-related uncertainty.

## Troubleshooting

| Problem | Checks |
| --- | --- |
| RDK resets or powers off | Stop the motors and check regulated supply, current capacity and connections. |
| Serial port missing or inaccessible | Check the USB data cable, actual device name, `dialout` membership after login and competing processes. |
| Motors turn incorrectly | Stop and disconnect motor power; verify channel assignment and direction settings. |
| `Hobot.GPIO` cannot be imported | Check the board image and Python environment, including the environment used by `sudo python3`. |
| Tracking inputs stay unchanged | Check physical pin mapping, wiring, mounting height, surface contrast and polarity. |
| DHT11 executable not found | Check the build output name, executable permission and location beside `line_follower.py`. |
| DHT11 service exits at startup | Check root privileges, `chrt`, `taskset`, CPU 7 availability and `/sys/class/gpio` compatibility. |
| DHT11 readings fail | Check supply, ground, data wiring, GPIO mapping, other processes using the sensor and the interval between marker events. |
| Motor communication fault | Confirm that the wheels stopped, disconnect motor power if needed, then check the USB cable, device path and driver before restarting. |
| CSV save failure | Stop the experiment, preserve the last saved file and check storage space and directory permissions. Do not rely on unsaved measurements. |
| A reading is `request_failure` or `timeout` | Check whether the DHT11 service is running and inspect the explanation; retain the failed row. |
| A file still contains `pending` after the run | Check for power loss, forced termination or a save error; retain the row as an incomplete event. |
| Detection numbers repeat across files | This is expected; use `RunID` with `Detection point` to distinguish events. |
| Readings have no coordinates | Join the log to a separately recorded station/event table. |
