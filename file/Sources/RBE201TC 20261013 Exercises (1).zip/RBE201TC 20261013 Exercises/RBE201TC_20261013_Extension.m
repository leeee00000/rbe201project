% RBE201TC | Extension | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% Floating-Point Values and Tolerances
x = 0.1+0.2; y = 0.3;
x==y                  % false
abs(x-y)              % about 5.55e-17
abs(x-y)<1e-12        % true
format long g         % display only
absTol=1e-10; relTol=1e-8;
tf = abs(x-y) <= absTol + ...
     relTol*max(abs(x),abs(y)); % true
disp(tf);
fprintf('x=%.17g, y=%.17g\n',x,y);

%% Floating-Point Values and Tolerances | Task 1: tighten the absolute tolerance
% Start from the unmodified baseline. In one line, tighten the strict absolute-tolerance threshold
% from 1e-12 to 1e-18 and store and display that decision as strict_tf. Rerun the whole baseline and
% compare strict_tf with the original combined decision tf; keep the combined rule unchanged.

%% Floating-Point Values and Tolerances | Task 2: change the display format
% Start from the unmodified baseline. Use short numeric display instead of long general display, and
% append one line displaying x and y together. Change only these two lines. Rerun and compare the
% final display with the existing 17-significant-digit fprintf output and the equality and tolerance
% decisions.

%% Numerical Debugging
%{
total=0;
for k=2:2:20
    total=total+k;
end
disp(total)           % 110: sum of even values
wrong=0;
for k=1:2:20
    wrong=wrong+k;
end
disp(wrong)           % 100: sum of odd values
%}

%% Numerical Debugging | Task 1: shorten the even-loop range
% Start from the unmodified baseline. Change the first loop's upper bound from 20 to 10, keeping its
% start at 2 and step at 2. Rerun and observe total and wrong, then update the first total-display
% comment to match the result. Change only these two lines and keep the second loop unchanged.

%% Numerical Debugging | Task 2: change the step to four
% Start from the unmodified baseline. Change the first loop's step from 2 to 4, keeping its start at 2
% and upper bound at 20. Rerun and observe the values accumulated and total, then update its display
% comment to describe the selected even values. Change only these two lines; keep the second loop
% unchanged.

%% Statistics and Missing-Value Rules
%{
scores=[50 60 80 90];
mean(scores)         % 70
min(scores)          % 50
max(scores)          % 90
std(scores)          % about 18.2574
std(scores,1)        % about 15.8114
sum(scores>=60)      % 3
sum(scores>mean(scores)) % 2
raw=[50 NaN 80 Inf];
valid=isfinite(raw); % [1 0 1 0]
clean=raw(valid);    % [50 80]
mean(clean)          % 65
std(clean)           % about 21.2132
sum(scores>=90)      % 1
disp(valid); disp(clean); disp(numel(clean));
%}

%% Statistics and Missing-Value Rules | Task 1: replace Inf with a finite value
% Start from the unmodified baseline. Replace raw's Inf entry with 20 and append one display line
% showing clean's valid count, mean and default sample standard deviation, in that order. Change only
% these two lines. Rerun and inspect the finite-value mask, retained values and summary; keep scores
% unchanged.

%% Statistics and Missing-Value Rules | Task 2: use N normalisation
% Start from the unmodified baseline. Change the two default standard-deviation evaluation lines to
% use N normalisation with flag 1. Store and display the scores result as sigma_N and the clean result
% as sigma_clean_N. Change only these two lines, rerun and compare them with the original
% sample-deviation values; keep the data and finite-value policy unchanged.

%% Maximum Values and Their Positions
%{
M=[1 9;9 5];
[largest,k]=max(M(:));  % largest=9, k=2
[r,c]=ind2sub(size(M),k);
[largest r c]          % [9 2 1]
allK=find(M==largest); % [2;3]
[allR,allC]=ind2sub(size(M),allK);
[allR allC]            % [2 1;1 2]
disp(M(:)); disp([largest k r c]); disp(allK);
%}

%% Maximum Values and Their Positions | Task 1: add one tied maximum
% Start from the unmodified baseline. In the matrix definition, change only the bottom-right entry
% from 5 to 9. Edit one line, rerun and compare the first maximum's linear and row-column positions
% with all tied locations.

%% Maximum Values and Their Positions | Task 2: display all position mappings together
% Start from the unmodified baseline. Append one display line combining allK, allR and allC into three
% columns ordered as linear index, row and column. Rerun and inspect how every tied maximum maps from
% its linear index to its row-column location; keep the original matrix.

%% Comparative Plot Panels
%{
t_mm=1:0.5:5;
m1=36*t_mm; m2=54*t_mm;
figure; subplot(1,2,1);
plot(t_mm,m1,'-o'); hold on;
plot(t_mm,m2,'-s'); hold off;
xlabel('Thickness (mm)');
ylabel('Predicted mass (g)');
legend('200 mm','300 mm');
axis([1 5 0 300]); grid on;
subplot(1,2,2);
plot(t_mm,m2-m1,'-o');
xlabel('Thickness (mm)');
ylabel('Mass increase (g)');
grid on;
% At t_mm=3:
% m1=108 g, m2=162 g
% difference=54 g
difference_g=m2-m1;
disp([t_mm(:) m1(:) m2(:) difference_g(:)]);
%}

%% Comparative Plot Panels | Task 1: compare a 250 mm plate
% Start from the unmodified baseline. Change m2's mass coefficient from 54 to 45 g/mm to represent a
% 250 mm plate, and change the second legend label from 300 mm to 250 mm. Edit only those two lines.
% Keep the 200 mm plate, density, width and solid-plate model unchanged; rerun and inspect both mass
% curves and their difference at 3 mm thickness.

%% Comparative Plot Panels | Task 2: narrow the left panel's display
% Start from the unmodified baseline. Edit the existing axis-limit line so the left panel shows
% thickness from 2 to 4 mm and predicted mass from 0 to 150 g. Change one line and rerun. Inspect the
% markers and line segments at the display boundaries, then compare the stored arrays and numerical
% table with the right-hand difference panel.

%% 3-D Points, Arrows and Surfaces [Optional]
%{
p=[1;2;3]; figure;
plot3(p(1),p(2),p(3),'o');
hold on;
quiver3(0,0,0,1,2,3,0);
xlabel('x (m)'); ylabel('y (m)');
zlabel('z (m)');
axis equal; grid on; view(3);
[X,Y]=meshgrid(-1:1,-1:1);
Z=X.^2+Y.^2;
figure; subplot(1,2,1);
mesh(X,Y,Z);
subplot(1,2,2);
surf(X,Y,Z);
disp(size(Z)); disp(Z);
%}

%% 3-D Points, Arrows and Surfaces | Task 1: refine the mathematical grid
% Optional. Start from the unmodified baseline. In the meshgrid definition, change both grid steps
% from 1 to 0.5 while retaining the domain from -1 to 1. Edit one line and rerun. Inspect the size,
% values and minimum and maximum of Z, and compare mesh with surf; retain the same mathematical
% formula, point and arrow.

%% 3-D Points, Arrows and Surfaces | Task 2: move the point and arrow together
% Optional. Start from the unmodified baseline. Move p to the coordinates (2, 1, 3) m and change the
% arrow's displacement components to the same values. Edit only the point-definition and quiver3
% lines. Keep the arrow's origin at (0, 0, 0), automatic scaling disabled and the mathematical surface
% unchanged; rerun and inspect the point and arrow together.

