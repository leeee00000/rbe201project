% RBE201TC | 2.3 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 2.3.1 Elementwise and Matrix Arithmetic
A = [1 2;3 4];
B = [5 6;7 8];
A.*B
A*B
A.^2
A^2
[10 20 30]./[2 4 5]

%% 2.3.1 | Task 1: Change B to the Identity
% Start from the original baseline. Change only B's definition to a two-by-two identity matrix using
% eye. Keep A unchanged. Rerun the section and compare the elementwise product with the matrix
% product.

%% 2.3.1 | Task 2: Display the Difference Between the Two Squares
% Start from the original baseline. Add two lines at the end: store the matrix square of A minus its
% elementwise square in difference, then display difference. Rerun the section and observe the entries
% and shape of the difference.

%% 2.3.2 Linear Systems and Vectors [Optional]
%{
C = [2 3;4 1]; b = [5;11];
x = C\b;     % [2.8;-0.2]
C*x-b        % near [0;0]
A = [1 2;3 4];
det(A)       % the determinant of A is -2
inv(A)       % the inverse of A is [-2 1;1.5 -0.5]
u = [1 2 3]; v = [4 5 6];
dot(u,v)       % 32
w = cross(u,v) % [-3 6 -3]
dot(u,w)       % 0
dot(v,w)       % 0
sqrt([4 9])    % [2 3]
%}

%% 2.3.2 | Task 1: Change the Right-hand Side
% Optional. Start from the original baseline. In the line defining C and b, change only b to a column
% vector whose first value is 8 and second value is 10. Keep C unchanged. Rerun the section and
% observe the solution x and the displayed residual of the linear system.

%% 2.3.2 | Task 2: Reverse the Cross-product Order
% Optional. Start from the original baseline. Add three lines at the end: store the cross product with
% v first and u second in reverseW, display reverseW, then display its sum with the original w. Rerun
% the section and observe how reversing the input order affects the vector and the sum.

