% RBE201TC | 3.1 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 3.1.1 Comparisons and Logical Arrays
A = [2 4 6 8]; B = [1 4 10 8];
A >= B              % [1 1 0 1] logical
A == B              % [0 1 0 1] logical
A ~= B              % [1 0 1 0] logical
v = [10 20 30 40];
mask = (v>=20) & (v<40); % [0 1 1 0]
v(mask)             % [20 30]
find(mask)          % [2 3]
sum(mask)           % 2

%% 3.1.1 | Task 1: include 40
% Add up to three lines to create maskClosed for values of v from 20 to 40, including both endpoints.
% Display the selected values, their original indices and their count. Run the whole section and
% compare the results with the original mask.

%% 3.1.1 | Task 2: compare OR with AND
% Restart from the original baseline. Add up to three lines to create maskOr by joining the conditions
% 'at least 20' and 'below 40' with OR. Display the mask, selected values and count, then compare them
% with the original AND selection.

%% 3.1.2 Batch Logic and Short-Circuit Logic
%{
v = [10 20 30 40];
mask = (v>=20) & (v<40);
otherMask = [false true false true];
andMask = mask & otherMask;
orMask = mask | otherMask;
notMask = ~mask;
anyVector = any(mask);
allVector = all(mask);
left = true; right = false;
scalarAnd = left && right;
scalarOr = left || right;
M = [true false true; false false true];
anyColumns = any(M);
allColumns = all(M);
anyWhole = any(M(:));
allWhole = all(M(:));
readings=[]; high=~isempty(readings) && max(readings)>40;
noDataOrHigh = isempty(readings) || max(readings)>40;
disp(andMask); disp(orMask); disp(notMask);
disp([anyVector allVector scalarAnd scalarOr]);
disp(anyColumns); disp(allColumns);
disp([anyWhole allWhole high noDataOrHigh]);
%}

%% 3.1.2 | Task 1: change the matrix's logical entries
% Change the definition of M so its first row contains three true values and its second row contains
% true, false and true, in that order. Run the section and compare the values and dimensions of
% anyColumns, allColumns, anyWhole and allWhole.

%% 3.1.2 | Task 2: evaluate the guarded data condition
% Restart from the original baseline. Change readings from an empty array to a row vector containing
% 39 and 45, while retaining the guarded condition for high. Run the section, compare high with
% noDataOrHigh, and trace whether each short-circuit operator evaluates its right-hand condition.

%% 3.1.3 Filtered Values and Original Positions
% {
% T_C = [35.2 36.5 NaN 37.8 38.1 36.0];
% keep = ~isnan(T_C) & (T_C>=36) & (T_C<=38);
% T_good_C = T_C(keep);       % [36.5 37.8 36.0]
% originalIndex = find(keep); % [2 4 6]
% numberKept = sum(keep);     % 3
% isnan(T_C)                 % [0 0 1 0 0 0]
% isfinite([1 NaN Inf])      % [1 0 0]
% disp(T_good_C); disp(originalIndex); disp(numberKept);
% }

%% 3.1.3 | Task 1: check endpoints and nonfinite values
% Add up to three lines to create a row vector named T_boundary containing 36, 38, NaN, Inf and -Inf,
% in that order. Create keep_boundary to retain only finite temperatures from 36 to 38 degrees
% Celsius, including both endpoints. Display the retained values and their original indices, then run
% the section.

%% 3.1.3 | Task 2: narrow the filtering interval
% Restart from the original baseline. Add up to three lines to create keepNarrow for non-NaN values of
% T_C that are at least 36 but below 37 degrees Celsius. Display the retained values, original indices
% and count. Run the section and compare the new selection with the original interval.

