% RBE201TC | 2.2 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 2.2.1 Rows, Columns and Dimensions
row = [10 20 30];   % 1-by-3
col = [10;20;30];   % 3-by-1
M = [1 2 3;4 5 6]; % 2-by-3
size(M)            % [2 3]
size(M,1)          % 2 rows
size(M,2)          % 3 columns
length(M)          % 3
numel(M)           % 6

% Display output.
disp(size(row));
disp(size(col));

%% 2.2.1 | Task 1: Change the Matrix to Two Rows and Four Columns
% Start from the original baseline. Change only the definition of M to a two-row, four-column matrix:
% use 1, 2, 3, 4 in its first row and 5, 6, 7, 8 in its second row. Rerun the section and compare
% size, length and numel.

%% 2.2.1 | Task 2: Change a Column Vector into a Row Vector
% Start from the original baseline. Change only the definition of col so that its existing values 10,
% 20, 30 form a row vector instead of a column vector. Keep row unchanged. Rerun the section and
% compare the two vector sizes.

%% 2.2.2 Two-Dimensional Indexing and end
%{
M = [1 2 3;4 5 6];
M(2,3)                % 6
M(2,:)                % [4 5 6]
M(:,2)                % [2;5]
M(:,2:3)              % [2 3;5 6]
M(end,:)              % [4 5 6]
M(1,end-1:end)        % [2 3]
M(end,1)              % 4
M(1,end)              % 3
%}

%% 2.2.2 | Task 1: Add a Row and Observe end
% Start from the original baseline. Extend the definition of M by adding a third row containing 7, 8,
% 9, keeping its existing two rows unchanged. Rerun the section and observe how end affects the
% last-row and last-row-first-column outputs, and how the whole second column changes.

%% 2.2.2 | Task 2: Display the First and Last Rows Together
% Start from the original baseline. Replace the line that displays M's second row with two lines:
% store its first and last rows together in selectedRows, in that order, then display selectedRows.
% Use end for the last row and retain every column. Rerun the section and observe the selected rows'
% order and shape.

%% 2.2.3 Linear Indexing and Transpose
%{
M = [1 2 3;4 5 6];
M(:)  % [1;4;2;5;3;6]
M(3)  % 2
M(end) % 6
M.'   % [1 4;2 5;3 6]
z = [1+2i 3];
z.'   % [1+2i;3]
z'    % [1-2i;3]
%}

%% 2.2.3 | Task 1: Display Two Indexing Methods Side by Side
% Start from the original baseline. Replace the third-linear-element display with three lines: store
% that element in linearValue, store the element at row 1 and column 3 in rowColumnValue, then display
% the two values side by side. Rerun the section and compare the two indexing methods.

%% 2.2.3 | Task 2: Change the Complex Input to Real Values
% Start from the original baseline. Change only z's definition by removing the imaginary component
% from its first value, keeping its real part and its second value unchanged. Rerun the section and
% compare the nonconjugating and conjugate transpose outputs.

%% 2.2.4 Array Modification and Generation
%{
M = [1 2 3;4 5 6];
M(2,1) = 40;
M(:,2) = [];
M   % [1 3;40 6]
0:0.25:1
% [0 0.25 0.5 0.75 1]
linspace(0,1,5)
% [0 0.25 0.5 0.75 1]
zeros(2,3); ones(2,3); eye(2);

% Display output.
disp(zeros(2,3));
disp(ones(2,3));
disp(eye(2));
%}

%% 2.2.4 | Task 1: Change Column Deletion to Row Deletion
% Start from the original baseline. Change only the deletion statement so that it deletes M's entire
% second row instead of its second column. Keep the preceding change of an element to 40. Rerun the
% section and observe M's remaining values and shape.

%% 2.2.4 | Task 2: Use Three linspace Points
% Start from the original baseline. Replace the linspace display with two lines: generate three
% equally spaced points from 0 to 1 in points, then display points. Keep the preceding colon sequence
% unchanged. Rerun the section and compare the spacing, number of points and endpoints.

