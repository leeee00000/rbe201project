% RBE201TC | 3.2 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 3.2.1 Strings: Full Equality and Substrings
commands = ["Start" "STOP" ...
            "Pause" "stop"];
strcmp(commands,"stop")
% [0 0 0 1]
strcmpi(commands,"stop")
% [0 1 0 1]
"stop" == "stop"   % true
files = ["report_Q1.pdf" ...
 "data_backup.mat" "Q1_results.csv"];
hasQ1 = contains(files,"Q1");
% [1 0 1]
files(hasQ1)
% report_Q1.pdf, Q1_results.csv
chars = 'stop';
charEqual = (chars=='stop');
disp(hasQ1); disp(charEqual);

%% 3.2.1 | Task 1: change target-command case
% Add up to two lines to define a string target containing uppercase STOP and display the results of
% matching commands to this target with strcmp and strcmpi. Run the section and identify which command
% positions each matching rule selects.

%% 3.2.1 | Task 2: add case-insensitive substring search
% Restart from the original baseline. Add up to three lines to search files for the lowercase
% substring q1 using contains. Store the default case-sensitive result in sensitiveQ1 and the result
% with IgnoreCase enabled in insensitiveQ1. Display the default mask and the filenames selected by the
% case-insensitive mask, then run the section.

%% 3.2.2 Branching and Discrete States
%{
mass_g = 144;
if mass_g <= 120
    category = "light";
elseif mass_g <= 160
    category = "medium";
else
    category = "heavy";
end
disp(category)  % medium
cmd = 'RUN';
switch lower(cmd)
    case 'run'
        disp('Start movement');
    case 'stop'
        disp('Stop movement');
    case 'pause'
        disp('Pause movement');
    otherwise, error('Unknown command');
end
%}

%% 3.2.2 | Task 1: test the mass-range boundary
% Change mass_g to 120 g and run the whole section. Identify the first matching mass-category branch
% and check whether the boundary is included. Update the result comment beside the category display to
% match the observed output.

%% 3.2.2 | Task 2: switch to the Pause command
% Restart from the original baseline. Change only the value of cmd to the character vector Pause. Run
% the section and observe how lower determines the switch case and which movement message is
% displayed.

