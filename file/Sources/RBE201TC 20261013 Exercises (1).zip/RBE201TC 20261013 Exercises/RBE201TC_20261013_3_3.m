% RBE201TC | 3.3 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 3.3.1 for, Preallocation and Bounded while
t_mm = [1 3 5];
mass_g = zeros(size(t_mm));
for k = 1:numel(t_mm)
    mass_g(k) = 36*t_mm(k);
end
mass_g   % [36 108 180]
x_m=0; step_m=0.25; target_m=1;
maxSteps=20; count=0;
while x_m<target_m && count<maxSteps
    x_m = x_m + step_m;
    count = count + 1;
end
[x_m count]          % [1 4]
reached = x_m>=target_m; % true
disp(reached);

%% 3.3.1 | Task 1: increase the while step
% Change step_m to 0.5 m while keeping the starting position and 1 m target unchanged. Run the section
% and inspect the final x_m, count and reached values. Update the result comment beside the
% position-and-count display to match the observed output.

%% 3.3.1 | Task 2: stop at the iteration limit
% Restart from the original baseline. Change maxSteps to 2 while retaining the original 0.25 m step
% and 1 m target. Run the section and inspect the final x_m, count and reached values. Update the two
% result comments to match the output and distinguish stopping at the iteration limit from reaching
% the target.

%% 3.3.2 continue, break and Nested Loops
%{
values=[2 NaN 4 10 6]; total=0;
for k=1:numel(values)
    if isnan(values(k))
        continue
    end
    if values(k)>8
        break
    end
    total=total+values(k);
end
A=[1 2;3 4]; B=[5 6;7 8];
assert(isequal(size(A),size(B)));
C=zeros(size(A));
for r=1:size(A,1)
    for c=1:size(A,2)
        C(r,c)=A(r,c)+B(r,c);
    end
end
C   % [6 8;10 12]
disp(total);
disp(k);
%}

%% 3.3.2 | Task 1: replace break with continue
% Replace break with continue only in the branch for a value above 8; retain the continue in the NaN
% branch. Run the whole section and inspect total and the final k to determine whether the value 6
% after 10 is processed.

%% 3.3.2 | Task 2: change elementwise addition to subtraction
% Restart from the original baseline. Change the nested-loop calculation so each entry of C is the
% corresponding entry of A minus the corresponding entry of B. Run the section and inspect C and its
% dimensions, then update its result comment to match the observed matrix.

