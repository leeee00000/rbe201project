% RBE201TC | 3.4 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

% Keep both local functions at the end of this file unchanged.

%% 3.4.1 Function Inputs, Outputs and Local Values
[good_C,idx]=filterTemps([35.2 36.5 NaN 37.8 38.1 36.0]);
disp(good_C); disp(idx);
disp(size(good_C)); disp(size(idx));

%% 3.4.1 | Task 1: call with a column vector
% Change only the input in the filterTemps caller to a column vector containing 36, NaN and 38 degrees
% Celsius, in that order. Keep the local function definition unchanged. Run the section and inspect
% the values, original indices and dimensions of good_C and idx.

%% 3.4.1 | Task 2: valid input with no matches
% Restart from the original baseline. Change only the input in the filterTemps caller to a row vector
% containing 35 and 39 degrees Celsius. Keep the local function definition unchanged. Run the section
% and inspect good_C and idx to distinguish valid input with no matching values from invalid empty
% input.

%% 3.4.2 Input Checks and Early Return
%{
tfClose = isEqualTol([1 2],[1 2+1e-10],1e-8);
tfShape = isEqualTol([1 2],[1;2],1e-8);
tfNaN = isEqualTol([1 NaN],[1 NaN],1e-8);
tfInf = isEqualTol([1 Inf],[1 Inf],1e-8);
tfAtTol = isEqualTol(0,0.125,0.125);
tfEmpty = isEqualTol([],[],1e-8);
disp([tfClose tfShape tfNaN tfInf tfAtTol tfEmpty]);
%}

%% 3.4.2 | Task 1: make both shapes agree
% Change only the inputs in the tfShape caller so both are identical column vectors containing 1
% followed by 2. Retain the original tolerance and the local isEqualTol definition. Run the section
% and compare tfShape and the summary display with the original row-versus-column case.

%% 3.4.2 | Task 2: increase the strict tolerance
% Restart from the original baseline. Change only the tolerance in the tfAtTol caller to 0.25,
% retaining the compared values 0 and 0.125 and the function's strict less-than rule. Run the section
% and compare tfAtTol and the summary display with the original tolerance-boundary case.

%% Local function support: keep unchanged
function [T_clean,idx] = filterTemps(T_C)
    bad = isempty(T_C) || ~isnumeric(T_C);
    bad = bad || ~isreal(T_C) || ~isvector(T_C);
    if bad
        error('A nonempty real numeric vector is required.');
    end
    keep = ~isnan(T_C) & (T_C>=36) & (T_C<=38);
    T_clean = T_C(keep);
    idx = find(keep);
end

function tf=isEqualTol(a,b,tol)
if ~isfloat(a) || ~isfloat(b) || ...
        ~isreal(a) || ~isreal(b)
    error('Real floating arrays required.');
end
if ~(isnumeric(tol) && isscalar(tol) && ...
        isreal(tol) && isfinite(tol) && tol>0)
    error('Finite positive tolerance required.');
end
tf=false;
if ~isequal(size(a),size(b))
    return
end
if any(~isfinite(a(:))) || ...
        any(~isfinite(b(:)))
    return
end
tf=all(abs(double(a(:))- ...
           double(b(:))) < tol);
end
