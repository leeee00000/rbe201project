% RBE201TC | 2.1 | MATLAB R2024b
% Run the baseline first. Restart from the original code for every task.
% Only the first subsection is enabled; later baselines are block-commented.
% Enable a later baseline by removing its standalone %{ and %} lines; use Run Section.
% Read each task requirement, edit the baseline, then run its entire section.
% Restore edits before another task; avoid Run All with multiple enabled subsections.
% Numerical comments describe original inputs; use actual outputs after edits.

%% 2.1.1 MATLAB Expressions, Powers and Roots
a = 2 + 3*4;          % 14
b = (2+3)*4;          % 20
c = 2^3;              % 8
e = -2^2;             % -4
f = (-2)^2;           % 4
sqrt([4 9 16])        % [2 3 4]
distance_m = sqrt(3^2+4^2); % 5
sin(pi/2)             % 1
sind(90)              % 1

% Display output.
disp([a b c e f distance_m]);

%% 2.1.1 | Task 1: Change Unary-minus Grouping
% Start from the original baseline. Change only the definition of e so that it squares the whole
% negative number -2, keeping f unchanged. Rerun the section and compare e with f.

%% 2.1.1 | Task 2: Change a Distance Input
% Start from the original baseline. In the definition of distance_m, change the displacement component
% from 3 m to 6 m while keeping the other component at 4 m. Rerun the section and observe the new
% distance in metres.

